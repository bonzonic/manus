import {
  MAX_CHAT_BYTES,
  encodeDataFrame,
  fingerprintFromSdp,
  parseDataFrame,
  utf8Bytes,
  validateDescription,
} from './protocol.js';

const MAX_BUFFERED_AMOUNT = 262_144;
const MAX_FRAME_RATE = 10;
const FRAME_WINDOW_MS = 1_000;
const MAX_ROLLING_MESSAGES = 200;
const MAX_ROLLING_BYTES = 512 * 1024;
const CHAT_IDLE_MS = 15 * 60 * 1_000;
const MAX_SESSION_MS = 60 * 60 * 1_000;
const DEFAULT_ICE_GATHERING_TIMEOUT_MS = 4_000;
const FP_PATTERN = /^(?:[0-9A-F]{2}:){31}[0-9A-F]{2}$/;

const defaultClock = {
  now: () => Date.now(),
  setTimeout: (fn, delay) => setTimeout(fn, delay),
  clearTimeout: (timer) => clearTimeout(timer),
};

function ownKeys(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? Object.keys(value).sort() : [];
}

function exactKeys(value, expected) {
  return ownKeys(value).join('\u0000') === [...expected].sort().join('\u0000');
}

function normalizeName(name) {
  if (typeof name !== 'string') throw new Error('invalid-name');
  const trimmed = name.trim();
  if (!trimmed || [...trimmed].length > 32) throw new Error('invalid-name');
  return trimmed;
}

function normalizeRoomId(roomId) {
  if (typeof roomId !== 'string') throw new Error('invalid-room');
  const trimmed = roomId.trim();
  if (!trimmed || trimmed.length > 128) throw new Error('invalid-room');
  return trimmed;
}

function normalizeFingerprint(value) {
  if (typeof value !== 'string') throw new Error('invalid-fingerprint');
  const trimmed = value.trim().toUpperCase();
  if (!FP_PATTERN.test(trimmed)) throw new Error('invalid-fingerprint');
  return trimmed;
}

function bind(target, eventName, handler) {
  if (target) target[`on${eventName}`] = handler;
}

function isOpenSocket(socket) {
  return Boolean(socket && socket.readyState === 1);
}

function isOpenChannel(channel) {
  return Boolean(channel && (channel.readyState === 'open' || channel.readyState === 1));
}

function defaultWebSocketUrl() {
  if (typeof location !== 'undefined' && location.host) {
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${location.host}/ws`;
  }
  return 'ws://127.0.0.1:4176/ws';
}

function validServerFrame(frame) {
  if (!frame || typeof frame !== 'object' || Array.isArray(frame) || frame.v !== 1 || typeof frame.type !== 'string') return false;
  if (frame.type === 'room') {
    return exactKeys(frame, ['v', 'type', 'roomId', 'selfId', 'role']) &&
      typeof frame.roomId === 'string' && typeof frame.selfId === 'string' &&
      (frame.role === 'creator' || frame.role === 'joiner');
  }
  if (frame.type === 'peer') {
    return exactKeys(frame, ['v', 'type', 'peer']) && frame.peer &&
      exactKeys(frame.peer, ['id', 'name']) && typeof frame.peer.id === 'string' && typeof frame.peer.name === 'string';
  }
  if (frame.type === 'signal') {
    return exactKeys(frame, ['v', 'type', 'description']) && validateDescription(frame.description);
  }
  if (frame.type === 'ended') {
    return exactKeys(frame, ['v', 'type', 'reason']) && typeof frame.reason === 'string' && frame.reason.length <= 64;
  }
  if (frame.type === 'error') {
    return exactKeys(frame, ['v', 'type', 'code']) && typeof frame.code === 'string' && /^[a-z0-9_-]{1,64}$/.test(frame.code);
  }
  return false;
}

function parseServerFrame(raw) {
  if (typeof raw !== 'string') throw new Error('invalid-signal');
  let frame;
  try { frame = JSON.parse(raw); } catch { throw new Error('invalid-signal'); }
  if (!validServerFrame(frame)) throw new Error('invalid-signal');
  return frame;
}

export function createSession(onEvent = () => {}, options = {}) {
  const clock = options.clock || defaultClock;
  const WebSocketCtor = options.WebSocket || globalThis.WebSocket;
  const PeerCtor = options.RTCPeerConnection || globalThis.RTCPeerConnection;
  const wsUrl = options.wsUrl || defaultWebSocketUrl();
  const iceGatheringTimeoutMs = Number.isFinite(options.iceGatheringTimeoutMs)
    ? Math.max(0, options.iceGatheringTimeoutMs)
    : DEFAULT_ICE_GATHERING_TIMEOUT_MS;

  let generation = 0;
  let active = false;
  let state = 'idle';
  let mode = null;
  let displayName = null;
  let role = null;
  let ws = null;
  let pc = null;
  let channel = null;
  let room = null;
  let peer = null;
  let localFingerprint = null;
  let peerFingerprint = null;
  let localConfirmed = false;
  let peerConfirmed = false;
  let verifiedSent = false;
  let offerSent = false;
  let answerSent = false;
  let remoteOfferApplied = false;
  let remoteAnswerApplied = false;
  let outgoingSeq = 1;
  let incomingSeq = 1;
  let channelOpen = false;
  let frameTimes = [];
  let rollingMessages = [];
  let rollingBytes = 0;
  let lifetimeTimer = null;
  let inactivityTimer = null;
  let terminalError = null;
  let certificatePromise = null;
  let peerSetupPromise = null;
  let cancelIceWait = null;
  let inboundQueue = Promise.resolve();

  function snapshot(extra = {}) {
    return {
      state,
      room: room ? { ...room } : null,
      peer: peer ? { ...peer } : null,
      fingerprints: { your: localFingerprint, peer: peerFingerprint },
      ...extra,
    };
  }

  function emit(event) {
    try { onEvent(event); } catch { /* Consumer failures cannot mutate session state. */ }
  }

  function emitState(nextState, extra = {}) {
    state = nextState;
    emit(snapshot(extra));
  }

  function sendSocket(frame) {
    if (!isOpenSocket(ws)) return false;
    try {
      ws.send(JSON.stringify(frame));
      return true;
    } catch {
      return false;
    }
  }

  function clearTimer(timer) {
    if (timer) clock.clearTimeout(timer);
  }

  function clearTimers() {
    clearTimer(lifetimeTimer);
    clearTimer(inactivityTimer);
    lifetimeTimer = null;
    inactivityTimer = null;
  }

  function addRollingMessage(text) {
    const bytes = utf8Bytes(text);
    rollingMessages.push({ text, bytes });
    rollingBytes += bytes;
    while (rollingMessages.length > MAX_ROLLING_MESSAGES || rollingBytes > MAX_ROLLING_BYTES) {
      const removed = rollingMessages.shift();
      rollingBytes -= removed.bytes;
    }
  }

  function scheduleInactivity() {
    clearTimer(inactivityTimer);
    inactivityTimer = clock.setTimeout(() => {
      if (active) end('chat-idle');
    }, CHAT_IDLE_MS);
  }

  function permitFrame() {
    const now = clock.now();
    frameTimes = frameTimes.filter((time) => now - time < FRAME_WINDOW_MS);
    if (frameTimes.length >= MAX_FRAME_RATE) return false;
    frameTimes.push(now);
    return true;
  }

  function activeGeneration(expectedGeneration) {
    return active && generation === expectedGeneration;
  }

  function closeTransports(notifyPeer = true) {
    cancelIceWait?.();
    cancelIceWait = null;
    if (notifyPeer && isOpenChannel(channel)) {
      try { channel.send(encodeDataFrame({ v: 1, type: 'leave' })); } catch { /* teardown is best effort */ }
    }
    if (notifyPeer) sendSocket({ v: 1, type: 'leave' });
    bind(channel, 'open', null);
    bind(channel, 'message', null);
    bind(channel, 'close', null);
    bind(pc, 'datachannel', null);
    bind(pc, 'icegatheringstatechange', null);
    bind(pc, 'connectionstatechange', null);
    try { channel?.close?.(); } catch { /* noop */ }
    try { pc?.close?.(); } catch { /* noop */ }
    try { if (ws && ws.readyState !== 3) ws.close?.(); } catch { /* noop */ }
  }

  function end(reason = 'left', { notifyPeer = true, error } = {}) {
    if (!active) return;
    active = false;
    generation += 1;
    clearTimers();
    closeTransports(notifyPeer);
    const endedError = error || terminalError;
    ws = null;
    pc = null;
    channel = null;
    room = null;
    peer = null;
    localFingerprint = null;
    peerFingerprint = null;
    localConfirmed = false;
    peerConfirmed = false;
    verifiedSent = false;
    offerSent = false;
    answerSent = false;
    remoteOfferApplied = false;
    remoteAnswerApplied = false;
    channelOpen = false;
    frameTimes = [];
    rollingMessages = [];
    rollingBytes = 0;
    outgoingSeq = 1;
    incomingSeq = 1;
    terminalError = null;
    certificatePromise = null;
    peerSetupPromise = null;
    inboundQueue = Promise.resolve();
    state = 'ended';
    emit({
      state: 'ended',
      room: null,
      peer: null,
      fingerprints: { your: null, peer: null },
      reason,
      ...(endedError ? { error: { code: endedError } } : {}),
      clear: true,
    });
  }

  function fail(code, reason = 'protocol-error') {
    if (!active) return;
    terminalError = code;
    emit(snapshot({ state: 'error', error: { code } }));
    end(reason, { error: code });
  }

  function attachChannel(nextChannel, expectedGeneration) {
    if (!nextChannel || !activeGeneration(expectedGeneration)) return;
    if (channel && channel !== nextChannel) return fail('duplicate-channel');
    channel = nextChannel;
    channelOpen = isOpenChannel(channel);
    bind(channel, 'open', () => {
      if (!activeGeneration(expectedGeneration)) return;
      channelOpen = true;
      emitState(localConfirmed && peerConfirmed ? 'verified' : 'unverified');
      maybeSendVerified(expectedGeneration);
      maybeVerified(expectedGeneration);
    });
    bind(channel, 'message', (event) => {
      if (!activeGeneration(expectedGeneration)) return;
      handleChannelMessage(event?.data, expectedGeneration);
    });
    bind(channel, 'close', () => {
      if (activeGeneration(expectedGeneration)) end('channel-closed', { notifyPeer: false });
    });
    if (channelOpen) {
      maybeSendVerified(expectedGeneration);
      maybeVerified(expectedGeneration);
    }
  }

  function maybeSendVerified(expectedGeneration) {
    if (!activeGeneration(expectedGeneration) || !localConfirmed || !channelOpen || verifiedSent) return;
    if (!permitFrame()) return fail('rate-limit', 'rate-limit');
    try {
      channel.send(encodeDataFrame({ v: 1, type: 'verified' }));
      verifiedSent = true;
    } catch {
      fail('channel-send-failed', 'channel-failed');
    }
  }

  function maybeVerified(expectedGeneration) {
    if (!activeGeneration(expectedGeneration) || !channelOpen || !localConfirmed || !peerConfirmed) return;
    if (state !== 'verified') {
      emitState('verified');
    }
    scheduleInactivity();
  }

  function handleChannelMessage(raw, expectedGeneration) {
    if (!permitFrame()) return fail('rate-limit', 'rate-limit');
    let frame;
    try { frame = parseDataFrame(raw); } catch { return fail('invalid-data', 'invalid-data'); }
    if (frame.type === 'leave') return end('peer-left', { notifyPeer: false });
    if (frame.type === 'verified') {
      if (peerConfirmed) return fail('duplicate-verification', 'invalid-data');
      peerConfirmed = true;
      emitState(localConfirmed && channelOpen ? 'verified' : 'unverified');
      return maybeVerified(expectedGeneration);
    }
    if (frame.type !== 'chat' || state !== 'verified' || !localConfirmed || !peerConfirmed || !channelOpen) {
      return fail('unverified-data', 'invalid-data');
    }
    if (frame.seq !== incomingSeq) return fail('invalid-sequence', 'invalid-data');
    incomingSeq += 1;
    addRollingMessage(frame.text);
    scheduleInactivity();
    emit(snapshot({ message: { direction: 'in', seq: frame.seq, text: frame.text } }));
  }

  async function certificateFor(expectedGeneration) {
    if (!activeGeneration(expectedGeneration)) return null;
    if (!certificatePromise) {
      certificatePromise = Promise.resolve().then(() => {
        if (typeof options.certificateFactory === 'function') return options.certificateFactory();
        if (options.certificate) return options.certificate;
        if (!PeerCtor?.generateCertificate) throw new Error('certificate-unavailable');
        return PeerCtor.generateCertificate({ name: 'ECDSA', namedCurve: 'P-256' });
      });
    }
    return certificatePromise;
  }

  function checkCertificate(certificate, localSdpFingerprint) {
    const getFingerprints = certificate?.getFingerprints;
    if (typeof getFingerprints !== 'function') return;
    const sha256 = getFingerprints.call(certificate)
      .filter((entry) => entry && typeof entry.algorithm === 'string' && entry.algorithm.toLowerCase() === 'sha-256')
      .map((entry) => normalizeFingerprint(entry.value));
    if (sha256.length !== 1 || sha256[0] !== localSdpFingerprint) throw new Error('certificate-mismatch');
  }

  async function waitForIce(expectedGeneration) {
    const currentPc = pc;
    if (!currentPc || !activeGeneration(expectedGeneration) || currentPc.iceGatheringState === 'complete') return;
    await new Promise((resolve, reject) => {
      let done = false;
      const previous = currentPc.onicegatheringstatechange;
      let timeout = null;
      const cleanup = () => {
        clearTimer(timeout);
        if (currentPc.onicegatheringstatechange === finish) currentPc.onicegatheringstatechange = previous || null;
        if (cancelIceWait === cancel) cancelIceWait = null;
      };
      const cancel = () => {
        if (done) return;
        done = true;
        cleanup();
        resolve();
      };
      const finish = () => {
        if (done) return;
        if (!activeGeneration(expectedGeneration) || pc !== currentPc) return cancel();
        if (currentPc.iceGatheringState !== 'complete') return;
        done = true;
        cleanup();
        resolve();
      };
      timeout = clock.setTimeout(() => {
        if (done) return;
        done = true;
        cleanup();
        reject(new Error('ice-timeout'));
      }, iceGatheringTimeoutMs);
      cancelIceWait = cancel;
      currentPc.onicegatheringstatechange = finish;
      finish();
    });
  }

  function normalizeDescription(description) {
    if (!description || typeof description !== 'object') return description;
    return { type: description.type, sdp: description.sdp };
  }

  async function setLocalAndFingerprint(description, certificate, expectedGeneration) {
    const requestedDescription = normalizeDescription(description);
    if (!validateDescription(requestedDescription)) throw new Error('invalid-description');
    await pc.setLocalDescription(requestedDescription);
    await waitForIce(expectedGeneration);
    const localDescription = normalizeDescription(pc?.localDescription || requestedDescription);
    if (!validateDescription(localDescription)) throw new Error('invalid-description');
    const fingerprint = fingerprintFromSdp(localDescription.sdp);
    checkCertificate(certificate, fingerprint);
    localFingerprint = fingerprint;
    emitState('unverified');
    return localDescription;
  }

  async function setupPeer(expectedGeneration) {
    if (!activeGeneration(expectedGeneration)) return;
    if (pc) return;
    if (peerSetupPromise) return peerSetupPromise;
    peerSetupPromise = (async () => {
      const certificate = await certificateFor(expectedGeneration);
      if (!activeGeneration(expectedGeneration)) return;
      const factory = options.peerFactory || ((config) => {
        if (!PeerCtor) throw new Error('peer-unavailable');
        return new PeerCtor(config);
      });
      const nextPc = await factory({ certificates: certificate ? [certificate] : [], role });
      if (!activeGeneration(expectedGeneration)) {
        try { nextPc?.close?.(); } catch { /* stale setup */ }
        return;
      }
      pc = nextPc;
      bind(pc, 'datachannel', (event) => attachChannel(event?.channel, expectedGeneration));
      bind(pc, 'connectionstatechange', () => {
        if (!activeGeneration(expectedGeneration)) return;
        if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected' || pc.connectionState === 'closed') {
          end('connection-failed', { notifyPeer: false });
        }
      });
      if (role === 'creator') {
        attachChannel(pc.createDataChannel('chat', { ordered: true }), expectedGeneration);
        const offer = await pc.createOffer();
        if (!activeGeneration(expectedGeneration) || offerSent) return;
        const localDescription = await setLocalAndFingerprint(offer, certificate, expectedGeneration);
        if (!activeGeneration(expectedGeneration)) return;
        offerSent = true;
        if (!sendSocket({ v: 1, type: 'signal', description: { type: localDescription.type, sdp: localDescription.sdp } })) {
          fail('signaling-failed', 'connection-failed');
        }
      }
    })();
    return peerSetupPromise;
  }

  async function applyRemoteSignal(description, expectedGeneration) {
    if (!activeGeneration(expectedGeneration)) return;
    if (!validateDescription(description)) return fail('invalid-description');
    if (role === 'creator') {
      if (!offerSent || answerSent || description.type !== 'answer' || remoteAnswerApplied) return fail('signal-order');
      remoteAnswerApplied = true;
      await pc.setRemoteDescription(description);
      if (!activeGeneration(expectedGeneration)) return;
      peerFingerprint = fingerprintFromSdp(description.sdp);
      emitState('unverified');
      return;
    }
    if (role !== 'joiner') return fail('signal-role');
    if (remoteOfferApplied || description.type !== 'offer') return fail('signal-order');
    remoteOfferApplied = true;
    await pc.setRemoteDescription(description);
    if (!activeGeneration(expectedGeneration)) return;
    peerFingerprint = fingerprintFromSdp(description.sdp);
    emitState('unverified');
    const certificate = await certificateFor(expectedGeneration);
    if (!activeGeneration(expectedGeneration)) return;
    const answer = await pc.createAnswer();
    const localDescription = await setLocalAndFingerprint(answer, certificate, expectedGeneration);
    if (!activeGeneration(expectedGeneration) || answerSent) return;
    answerSent = true;
    if (!sendSocket({ v: 1, type: 'signal', description: { type: localDescription.type, sdp: localDescription.sdp } })) {
      fail('signaling-failed', 'connection-failed');
    }
  }

  async function handleServerMessage(raw, expectedGeneration) {
    if (!activeGeneration(expectedGeneration)) return;
    let frame;
    try { frame = parseServerFrame(raw); } catch { return fail('invalid-signal'); }
    try {
      if (frame.type === 'room') {
        if (room || peer || frame.role !== role) return fail('signal-order');
        room = { roomId: frame.roomId, selfId: frame.selfId, role: frame.role };
        emitState('waiting');
        return;
      }
      if (frame.type === 'peer') {
        if (!room || peer) return fail('signal-order');
        peer = { id: frame.peer.id, name: frame.peer.name };
        emitState('waiting');
        await setupPeer(expectedGeneration);
        return;
      }
      if (frame.type === 'signal') {
        if (!room || !peer) return fail('signal-order');
        await setupPeer(expectedGeneration);
        await applyRemoteSignal(frame.description, expectedGeneration);
        return;
      }
      if (frame.type === 'ended') return end(frame.reason || 'ended', { notifyPeer: false });
      if (frame.type === 'error') return fail(frame.code, 'server-error');
    } catch (error) {
      if (!activeGeneration(expectedGeneration)) return;
      const code = error?.message === 'certificate-mismatch' ? 'certificate-mismatch' :
        error?.message === 'certificate-unavailable' ? 'certificate-unavailable' : 'negotiation-failed';
      fail(code);
    }
  }

  function createSocket(expectedGeneration, firstFrame) {
    if (typeof WebSocketCtor !== 'function') throw new Error('websocket-unavailable');
    ws = new WebSocketCtor(wsUrl);
    bind(ws, 'open', () => {
      if (!activeGeneration(expectedGeneration)) return;
      if (!sendSocket(firstFrame)) fail('signaling-failed', 'connection-failed');
    });
    bind(ws, 'message', (event) => {
      inboundQueue = inboundQueue
        .then(() => handleServerMessage(event?.data, expectedGeneration))
        .catch(() => {});
    });
    bind(ws, 'error', () => {
      if (activeGeneration(expectedGeneration)) fail('connection-failed', 'connection-failed');
    });
    bind(ws, 'close', () => {
      if (activeGeneration(expectedGeneration)) end('disconnected', { notifyPeer: false });
    });
    if (isOpenSocket(ws)) sendSocket(firstFrame);
  }

  function start(nextMode, name, roomId) {
    try {
      const normalizedName = normalizeName(name);
      const normalizedRoom = roomId === undefined ? null : normalizeRoomId(roomId);
      if (active) end('replaced');
      generation += 1;
      const expectedGeneration = generation;
      active = true;
      mode = nextMode;
      displayName = normalizedName;
      role = nextMode === 'create' ? 'creator' : 'joiner';
      state = 'connecting';
      room = null;
      peer = null;
      localFingerprint = null;
      peerFingerprint = null;
      localConfirmed = false;
      peerConfirmed = false;
      verifiedSent = false;
      offerSent = false;
      answerSent = false;
      remoteOfferApplied = false;
      remoteAnswerApplied = false;
      channelOpen = false;
      frameTimes = [];
      rollingMessages = [];
      rollingBytes = 0;
      outgoingSeq = 1;
      incomingSeq = 1;
      terminalError = null;
      emitState('connecting');
      lifetimeTimer = clock.setTimeout(() => {
        if (activeGeneration(expectedGeneration)) end('session-expired');
      }, MAX_SESSION_MS);
      createSocket(expectedGeneration, nextMode === 'create'
        ? { v: 1, type: 'create', name: normalizedName }
        : { v: 1, type: 'join', name: normalizedName, roomId: normalizedRoom });
    } catch (error) {
      emit({ state: 'error', error: { code: error?.message || 'start-failed' }, room: null, peer: null, fingerprints: { your: null, peer: null } });
    }
  }

  return {
    create(name) { start('create', name); },
    join(name, roomId) { start('join', name, roomId); },
    confirmPeer(matches) {
      if (!active || typeof matches !== 'boolean') throw new Error('confirmation-unavailable');
      if (!localFingerprint || !peerFingerprint) throw new Error('fingerprints-unavailable');
      if (!matches) return end('fingerprint-mismatch');
      localConfirmed = true;
      emitState('unverified');
      const expectedGeneration = generation;
      maybeSendVerified(expectedGeneration);
      maybeVerified(expectedGeneration);
    },
    send(text) {
      if (!active || state !== 'verified' || !channelOpen || !localConfirmed || !peerConfirmed) throw new Error('not-verified');
      if (typeof text !== 'string' || !text.trim() || utf8Bytes(text) > MAX_CHAT_BYTES) throw new Error('invalid-message');
      if (channel.bufferedAmount > MAX_BUFFERED_AMOUNT) throw new Error('send-buffer-full');
      if (!permitFrame()) {
        end('rate-limit');
        throw new Error('rate-limit');
      }
      const frame = { v: 1, type: 'chat', seq: outgoingSeq, text };
      const encoded = encodeDataFrame(frame);
      try { channel.send(encoded); } catch { end('channel-failed'); throw new Error('channel-failed'); }
      outgoingSeq += 1;
      addRollingMessage(text);
      scheduleInactivity();
      emit(snapshot({ message: { direction: 'out', seq: frame.seq, text } }));
    },
    end(reason = 'left') { end(reason); },
  };
}
