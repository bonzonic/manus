import http from 'node:http';
import fs from 'node:fs';
import { promises as fsPromises } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';
import { validateDescription } from './public/protocol.js';

const MAX_ROOMS = 100;
const MAX_CONNECTIONS = 200;
const SOCKET_PAYLOAD_BYTES = 128 * 1024;
const MAX_FRAME_BYTES = SOCKET_PAYLOAD_BYTES;
const FRAME_WINDOW_MS = 1000;
const FRAME_LIMIT = 10;
const DEFAULT_ROOM_TTL = 10 * 60 * 1000;
const DEFAULT_SESSION_TTL = 60 * 60 * 1000;
const DEFAULT_PUBLIC_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'public');

const MIME_TYPES = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.svg', 'image/svg+xml'],
  ['.ico', 'image/x-icon'],
]);

function randomId(bytes = 12) {
  return randomBytes(bytes).toString('hex');
}

function roomCode() {
  return randomBytes(6).toString('hex').toUpperCase();
}

function frame(type, extra = {}) {
  return JSON.stringify({ v: 1, type, ...extra });
}

function exactKeys(value, keys) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const actual = Object.keys(value).sort();
  return actual.length === keys.length && actual.every((key, index) => key === [...keys].sort()[index]);
}

function validName(name) {
  return typeof name === 'string' && name.trim().length >= 1 && name.trim().length <= 32;
}

function validRoomId(roomId) {
  return typeof roomId === 'string' && /^[A-F0-9]{12}$/.test(roomId);
}

function validDescription(description) {
  return exactKeys(description, ['type', 'sdp']) &&
    (description.type === 'offer' || description.type === 'answer') &&
    typeof description.sdp === 'string' &&
    description.sdp.length > 0 && description.sdp.length <= 65536 &&
    validateDescription(description);
}

export function createChatServer({
  port = 4176,
  host = '127.0.0.1',
  publicDir = DEFAULT_PUBLIC_DIR,
  roomTtlMs = DEFAULT_ROOM_TTL,
  maxSessionMs = DEFAULT_SESSION_TTL,
} = {}) {
  const rooms = new Map();
  const connections = new Set();
  const counters = {
    signalsForwarded: 0,
    rejectedFrames: 0,
  };
  let actualPort = port;
  let closed = false;

  const headers = {
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; connect-src 'self' ws:; img-src 'self'; style-src 'self'; script-src 'self'",
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Cross-Origin-Resource-Policy': 'same-origin',
  };

  function privacy() {
    return {
      activeRooms: rooms.size,
      activeConnections: connections.size,
      signalsForwarded: counters.signalsForwarded,
      rejectedFrames: counters.rejectedFrames,
      applicationMessagesForwarded: 0,
      payloadsStored: false,
    };
  }

  function send(ws, value) {
    if (ws.readyState === WebSocket.OPEN) ws.send(value);
  }

  function sendError(ws, code) {
    counters.rejectedFrames += 1;
    send(ws, frame('error', { code }));
  }

  function detach(ws) {
    connections.delete(ws);
    ws.retired = true;
    if (ws.context) ws.context = null;
  }

  function clearRoomTimers(room) {
    clearTimeout(room.waitTimer);
    clearTimeout(room.sessionTimer);
  }

  function endRoom(room, reason, initiator = null) {
    if (!room || room.ended) return;
    room.ended = true;
    rooms.delete(room.id);
    clearRoomTimers(room);
    const members = [...room.members];
    for (const member of members) {
      if (member !== initiator || member.readyState === WebSocket.OPEN) send(member, frame('ended', { reason }));
      detach(member);
    }
    for (const member of members) {
      if (member.readyState === WebSocket.OPEN || member.readyState === WebSocket.CONNECTING) {
        member.close(1000, reason.slice(0, 123));
      }
    }
  }

  function rejectUpgrade(socket, status = 403) {
    socket.write(`HTTP/1.1 ${status} Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
    socket.destroy();
  }

  function allowedOrigin(origin) {
    if (typeof origin !== 'string' || origin.length === 0) return false;
    const allowed = new Set([
      `http://127.0.0.1:${actualPort}`,
      `http://localhost:${actualPort}`,
    ]);
    return allowed.has(origin);
  }

  function removeConnection(ws) {
    const context = ws.context;
    if (context?.room && !context.room.ended) {
      endRoom(context.room, 'disconnected', ws);
    } else {
      detach(ws);
    }
  }

  function handleCreate(ws, request) {
    if (ws.context?.room || !exactKeys(request, ['v', 'type', 'name']) || request.v !== 1 || request.type !== 'create' || !validName(request.name)) {
      sendError(ws, 'invalid_request');
      return;
    }
    if (rooms.size >= MAX_ROOMS) {
      sendError(ws, 'capacity');
      return;
    }
    const id = roomCode();
    const room = {
      id,
      createdAt: Date.now(),
      ended: false,
      members: [ws],
      waitTimer: null,
      sessionTimer: null,
    };
    room.waitTimer = setTimeout(() => endRoom(room, 'expired'), roomTtlMs);
    room.sessionTimer = setTimeout(() => endRoom(room, 'expired'), maxSessionMs);
    rooms.set(id, room);
    ws.context = {
      id: randomId(),
      room,
      role: 'creator',
      name: request.name.trim(),
      signalState: 'offer',
      rateStarted: Date.now(),
      rateCount: 0,
    };
    send(ws, frame('room', { roomId: id, selfId: ws.context.id, role: 'creator' }));
  }

  function handleJoin(ws, request) {
    if (ws.context?.room || !exactKeys(request, ['v', 'type', 'name', 'roomId']) || request.v !== 1 || request.type !== 'join' || !validName(request.name) || !validRoomId(request.roomId)) {
      sendError(ws, 'invalid_request');
      return;
    }
    const room = rooms.get(request.roomId);
    if (!room) {
      sendError(ws, 'room_not_found');
      return;
    }
    if (room.members.length >= 2) {
      sendError(ws, 'room_full');
      return;
    }
    room.members.push(ws);
    clearTimeout(room.waitTimer);
    ws.context = {
      id: randomId(),
      room,
      role: 'joiner',
      name: request.name.trim(),
      signalState: 'await-offer',
      rateStarted: Date.now(),
      rateCount: 0,
    };
    const creator = room.members[0];
    creator.context.signalState = 'offer';
    send(ws, frame('room', { roomId: room.id, selfId: ws.context.id, role: 'joiner' }));
    send(creator, frame('peer', { peer: { id: ws.context.id, name: ws.context.name } }));
    send(ws, frame('peer', { peer: { id: creator.context.id, name: creator.context.name } }));
  }

  function handleSignal(ws, request) {
    if (!ws.context?.room || !exactKeys(request, ['v', 'type', 'description']) || request.v !== 1 || request.type !== 'signal' || !validDescription(request.description)) {
      sendError(ws, 'invalid_request');
      return;
    }
    const { room, role, signalState } = ws.context;
    const expected = role === 'creator' ? 'offer' : 'answer';
    if (request.description.type !== expected || signalState !== (role === 'creator' ? 'offer' : 'answer')) {
      sendError(ws, 'invalid_state');
      return;
    }
    const target = room.members.find((member) => member !== ws);
    if (!target || !target.context || target.readyState !== WebSocket.OPEN) {
      sendError(ws, 'invalid_state');
      return;
    }
    send(target, frame('signal', { description: request.description }));
    counters.signalsForwarded += 1;
    if (role === 'creator') {
      ws.context.signalState = 'await-answer';
      target.context.signalState = 'answer';
    } else {
      ws.context.signalState = 'complete';
      target.context.signalState = 'complete';
    }
  }

  function handleMessage(ws, data, isBinary) {
    if (ws.retired || ws.readyState !== WebSocket.OPEN) return;
    const now = Date.now();
    if (now - ws.rateStarted >= FRAME_WINDOW_MS) {
      ws.rateStarted = now;
      ws.rateCount = 0;
    }
    if (++ws.rateCount > FRAME_LIMIT) {
      sendError(ws, 'rate_limited');
      if (ws.context?.room && !ws.context.room.ended) {
        endRoom(ws.context.room, 'disconnected', ws);
      } else {
        detach(ws);
        if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.close(1008, 'rate_limited');
      }
      return;
    }
    if (isBinary || !Buffer.isBuffer(data) || data.byteLength > MAX_FRAME_BYTES) {
      sendError(ws, data?.byteLength > MAX_FRAME_BYTES ? 'oversized_frame' : 'malformed_frame');
      return;
    }
    let request;
    try {
      request = JSON.parse(data.toString('utf8'));
    } catch {
      sendError(ws, 'malformed_frame');
      return;
    }
    if (!request || typeof request !== 'object' || Array.isArray(request) || request.v !== 1 || typeof request.type !== 'string') {
      sendError(ws, 'malformed_frame');
      return;
    }
    if (request.type === 'create') return handleCreate(ws, request);
    if (request.type === 'join') return handleJoin(ws, request);
    if (request.type === 'signal') return handleSignal(ws, request);
    if (request.type === 'leave') {
      if (!exactKeys(request, ['v', 'type']) || !ws.context?.room) {
        sendError(ws, 'invalid_state');
        return;
      }
      endRoom(ws.context.room, 'left');
      return;
    }
    sendError(ws, 'unsupported_frame');
  }

  async function serveStatic(req, res) {
    const pathname = new URL(req.url, `http://${host}`).pathname;
    if (pathname === '/api/privacy') {
      if (req.method !== 'GET') {
        res.writeHead(405, { ...headers, Allow: 'GET' });
        res.end();
        return;
      }
      const body = JSON.stringify(privacy());
      res.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
      res.end(body);
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { ...headers, Allow: 'GET, HEAD' });
      res.end();
      return;
    }
    let decoded;
    try {
      decoded = decodeURIComponent(pathname);
    } catch {
      res.writeHead(400, headers);
      res.end();
      return;
    }
    const segments = decoded.split('/');
    if (segments.includes('..') || decoded.includes('\\') || decoded.includes('\0')) {
      res.writeHead(400, headers);
      res.end();
      return;
    }
    const relative = decoded === '/' ? 'index.html' : decoded.replace(/^\/+/, '');
    const root = path.resolve(publicDir);
    const target = path.resolve(root, relative);
    if (target !== root && !target.startsWith(`${root}${path.sep}`)) {
      res.writeHead(400, headers);
      res.end();
      return;
    }
    try {
      const rootReal = await fsPromises.realpath(root);
      const targetReal = await fsPromises.realpath(target);
      const relativeReal = path.relative(rootReal, targetReal);
      if (relativeReal.startsWith(`..${path.sep}`) || relativeReal === '..' || path.isAbsolute(relativeReal)) {
        res.writeHead(404, headers);
        res.end();
        return;
      }
      const stat = await fsPromises.stat(targetReal);
      if (!stat.isFile()) throw new Error('not file');
      const body = await fsPromises.readFile(targetReal);
      res.writeHead(200, { ...headers, 'Content-Type': MIME_TYPES.get(path.extname(targetReal).toLowerCase()) ?? 'application/octet-stream', 'Content-Length': body.byteLength });
      if (req.method === 'HEAD') res.end(); else res.end(body);
    } catch {
      res.writeHead(404, headers);
      res.end();
    }
  }

  const server = http.createServer((req, res) => {
    serveStatic(req, res).catch(() => {
      if (!res.headersSent) res.writeHead(500, headers);
      res.end();
    });
  });
  const wss = new WebSocketServer({ noServer: true, maxPayload: SOCKET_PAYLOAD_BYTES });

  server.on('upgrade', (req, socket, head) => {
    let pathname;
    try { pathname = new URL(req.url, `http://${host}`).pathname; } catch { rejectUpgrade(socket, 400); return; }
    if (pathname !== '/' && pathname !== '/ws') { rejectUpgrade(socket, 404); return; }
    if (!allowedOrigin(req.headers.origin)) { rejectUpgrade(socket, 403); return; }
    if (connections.size >= MAX_CONNECTIONS) { rejectUpgrade(socket, 503); return; }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });

  wss.on('connection', (ws) => {
    connections.add(ws);
    ws.context = null;
    ws.retired = false;
    ws.rateStarted = Date.now();
    ws.rateCount = 0;
    ws.on('message', (data, isBinary) => handleMessage(ws, data, isBinary));
    ws.on('error', () => {});
    ws.on('close', () => removeConnection(ws));
  });

  async function listen() {
    if (closed) throw new Error('server closed');
    await new Promise((resolve, reject) => {
      const onError = (error) => { server.off('listening', onListen); reject(error); };
      const onListen = () => { server.off('error', onError); actualPort = server.address().port; resolve(); };
      server.once('error', onError);
      server.once('listening', onListen);
      server.listen(port, host);
    });
    return { port: actualPort };
  }

  async function close() {
    if (closed) return;
    closed = true;
    for (const room of [...rooms.values()]) endRoom(room, 'closed');
    for (const ws of [...connections]) {
      detach(ws);
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.terminate();
    }
    await new Promise((resolve) => {
      wss.close(() => {
        if (!server.listening) resolve();
        else server.close(() => resolve());
      });
    });
  }

  return { server, wss, listen, close };
}

const invokedFile = process.argv[1] && path.resolve(process.argv[1]);
if (invokedFile && invokedFile === path.resolve(fileURLToPath(import.meta.url))) {
  const application = createChatServer({ port: Number(process.env.PORT) || 4176 });
  application.listen().then(({ port }) => {
    process.stdout.write(`Local chat server listening on http://127.0.0.1:${port}\n`);
  }).catch((error) => {
    process.stderr.write(`${error.message}\n`);
    process.exitCode = 1;
  });
}
