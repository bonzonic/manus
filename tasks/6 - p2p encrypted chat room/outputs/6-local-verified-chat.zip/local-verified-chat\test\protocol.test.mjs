import test from 'node:test';
import assert from 'node:assert/strict';
import {
  fingerprintFromSdp,
  validateDescription,
  utf8Bytes,
  parseDataFrame,
  encodeDataFrame,
} from '../public/protocol.js';

const FP = 'AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99';
const FP2 = '11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00';

function sdp({fingerprints = [FP], media = 'application', bundle = true} = {}) {
  const lines = [
    'v=0', 'o=- 1 2 IN IP4 127.0.0.1', 's=-', 't=0 0',
    ...(bundle ? ['a=group:BUNDLE 0'] : []),
    `m=${media} 9 UDP/TLS/RTP/SAVPF 111`, 'c=IN IP4 0.0.0.0', 'a=mid:0',
    ...fingerprints.map((value) => `a=fingerprint:sha-256 ${value}`),
    'a=setup:actpass',
  ];
  return `${lines.join('\r\n')}\r\n`;
}

const description = (value = {}) => ({ type: 'offer', sdp: sdp(), ...value });

test('fingerprintFromSdp canonicalizes a single SHA-256 fingerprint and tolerates identical duplicate lines', () => {
  assert.equal(fingerprintFromSdp(sdp({ fingerprints: [FP.toLowerCase(), FP] })), FP);
  assert.equal(fingerprintFromSdp(sdp()), FP);
});

test('validateDescription enforces data-only SDP and rejects ambiguous or malformed fingerprints', () => {
  assert.equal(validateDescription(description()), true);
  assert.equal(validateDescription(description({ type: 'answer' })), true);
  assert.equal(validateDescription(description({ sdp: sdp({ fingerprints: [FP, FP2] }) })), false);
  assert.equal(validateDescription(description({ sdp: sdp({ media: 'audio' }) })), false);
  assert.equal(validateDescription(description({ sdp: sdp({ bundle: false }) })), false);
  assert.equal(validateDescription({ type: 'offer', sdp: 'v=0\r\n' }), false);
  assert.equal(validateDescription({ type: 'pranswer', sdp: sdp() }), false);
  assert.equal(validateDescription({ type: 'offer', sdp: sdp(), extra: true }), false);
});

test('utf8Bytes counts Unicode code points as encoded bytes', () => {
  assert.equal(utf8Bytes('hello'), 5);
  assert.equal(utf8Bytes('🙂'), 4);
  assert.equal(utf8Bytes('é'), 2);
});

test('data frames encode and parse only the frozen protocol', () => {
  for (const frame of [{ v: 1, type: 'verified' }, { v: 1, type: 'leave' }, { v: 1, type: 'chat', seq: 1, text: 'hello' }]) {
    assert.deepEqual(parseDataFrame(encodeDataFrame(frame)), frame);
  }
  assert.throws(() => encodeDataFrame({ v: 1, type: 'chat', seq: 0, text: 'x' }));
  assert.throws(() => encodeDataFrame({ v: 1, type: 'chat', seq: 1, text: 'x', extra: true }));
  assert.throws(() => parseDataFrame(JSON.stringify({ v: 1, type: 'chat', seq: 2, text: 'x', extra: true })));
  assert.throws(() => parseDataFrame('{not-json'));
  assert.throws(() => parseDataFrame(new Uint8Array([1, 2, 3])));
});

test('chat and complete frame byte caps are enforced', () => {
  assert.throws(() => encodeDataFrame({ v: 1, type: 'chat', seq: 1, text: '🙂'.repeat(1024 + 1) }));
  assert.throws(() => parseDataFrame(JSON.stringify({ v: 1, type: 'chat', seq: 1, text: 'x'.repeat(32760) })));
});
