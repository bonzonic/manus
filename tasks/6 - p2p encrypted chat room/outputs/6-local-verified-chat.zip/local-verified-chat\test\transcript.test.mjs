import test from 'node:test';
import assert from 'node:assert/strict';
import { createTranscriptTracker } from '../public/transcript.js';

function fakeTranscript(empty) {
  const children = [empty];
  return {
    get children() { return children; },
    append(node) { children.push(node); node.parent = this; },
  };
}

function fakeMessage(id) {
  return {
    id,
    remove() {
      const index = this.parent?.children.indexOf(this);
      if (index >= 0) this.parent.children.splice(index, 1);
    },
  };
}

test('transcript removes oldest DOM nodes at message and UTF-8 byte caps, then resets tracking', () => {
  const empty = { id: 'empty', hidden: false };
  const transcript = fakeTranscript(empty);
  const tracker = createTranscriptTracker({ transcript, empty });

  for (let index = 0; index < 201; index += 1) tracker.add(fakeMessage(index), 'x');
  assert.equal(transcript.children.filter((node) => node !== empty).length, 200);
  assert.equal(transcript.children[1].id, 1);

  tracker.clear();
  const first = fakeMessage('first');
  const second = fakeMessage('second');
  const third = fakeMessage('third');
  tracker.add(first, '🙂'.repeat(65_536));
  tracker.add(second, '🙂'.repeat(65_536));
  tracker.add(third, 'x');
  assert.deepEqual(transcript.children.map((node) => node.id), ['empty', 'second', 'third']);
  assert.equal(empty.hidden, true);
});
