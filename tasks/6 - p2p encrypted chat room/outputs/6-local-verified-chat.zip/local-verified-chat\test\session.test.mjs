import test from 'node:test';
import assert from 'node:assert/strict';
import { createSession } from '../public/session.js';
import { encodeDataFrame } from '../public/protocol.js';

const FP = 'AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99';
const SDP = `v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\nm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\nc=IN IP4 0.0.0.0\r\na=mid:0\r\na=fingerprint:sha-256 ${FP}\r\na=setup:actpass\r\n`;
const CERT = { getFingerprints: () => [{ algorithm: 'sha-256', value: FP }] };

class FakeClock {
  constructor() { this.time = 0; this.timers = []; }
  now = () => this.time;
  setTimeout = (fn, delay) => { const timer = { fn, at: this.time + delay, cancelled: false }; this.timers.push(timer); return timer; };
  clearTimeout = (timer) => { if (timer) timer.cancelled = true; };
  advance(ms) {
    this.time += ms;
    for (const timer of [...this.timers]) {
      if (!timer.cancelled && timer.at <= this.time) { timer.cancelled = true; timer.fn(); }
    }
  }
}

class FakeSocket {
  static instances = [];
  constructor() { this.sent = []; this.readyState = 0; FakeSocket.instances.push(this); }
  send(raw) { this.sent.push(JSON.parse(raw)); }
  open() { this.readyState = 1; this.onopen?.(); }
  message(frame) { this.onmessage?.({ data: JSON.stringify(frame) }); }
  close() { this.readyState = 3; this.onclose?.(); }
}

class FakeChannel {
  constructor() { this.readyState = 'connecting'; this.sent = []; this.bufferedAmount = 0; }
  send(raw) { this.sent.push(JSON.parse(raw)); }
  open() { this.readyState = 'open'; this.onopen?.(); }
  message(frame) { this.onmessage?.({ data: typeof frame === 'string' ? frame : JSON.stringify(frame) }); }
  close() { this.readyState = 'closed'; this.onclose?.(); }
}

class FakePeer {
  constructor() { this.iceGatheringState = 'complete'; this.localDescription = null; this.remoteDescription = null; this.channel = new FakeChannel(); this.closed = false; }
  createDataChannel() { return this.channel; }
  async createOffer() { return { type: 'offer', sdp: SDP }; }
  async createAnswer() { return { type: 'answer', sdp: SDP }; }
  async setLocalDescription(desc) { this.localDescription = desc; }
  async setRemoteDescription(desc) { this.remoteDescription = desc; }
  close() { this.closed = true; }
}

class NativeDescription {
  constructor(type, sdp) {
    Object.defineProperty(this, '_type', { value: type });
    Object.defineProperty(this, '_sdp', { value: sdp });
  }
  get type() { return this._type; }
  get sdp() { return this._sdp; }
}

class NativeDescriptionPeer extends FakePeer {
  async createOffer() { return new NativeDescription('offer', SDP); }
  async setLocalDescription(description) {
    this.localDescription = new NativeDescription(description.type, description.sdp);
  }
}

function makeSession(extra = {}) {
  const events = [];
  const socket = new FakeSocket();
  const peer = new FakePeer();
  const clock = new FakeClock();
  const session = createSession((event) => events.push(event), {
    WebSocket: class { constructor() { return socket; } },
    peerFactory: () => peer,
    certificateFactory: async () => CERT,
    clock,
    iceGatheringTimeoutMs: 1,
    ...extra,
  });
  return { session, events, socket, peer, clock };
}

async function establishCreator(extra = {}) {
  const fixture = makeSession(extra);
  fixture.session.create('Alice');
  fixture.socket.open();
  fixture.socket.message({ v: 1, type: 'room', roomId: 'ABCD', selfId: 'one', role: 'creator' });
  fixture.socket.message({ v: 1, type: 'peer', peer: { id: 'two', name: 'Bob' } });
  await new Promise((resolve) => setImmediate(resolve));
  fixture.socket.message({ v: 1, type: 'signal', description: { type: 'answer', sdp: SDP } });
  await new Promise((resolve) => setImmediate(resolve));
  return fixture;
}

test('normalizes prototype-backed native RTCSessionDescription at the local boundary', async () => {
  const nativePeer = new NativeDescriptionPeer();
  const fixture = makeSession({ peerFactory: () => nativePeer });
  fixture.session.create('Alice');
  fixture.socket.open();
  fixture.socket.message({ v: 1, type: 'room', roomId: 'ABCD', selfId: 'one', role: 'creator' });
  fixture.socket.message({ v: 1, type: 'peer', peer: { id: 'two', name: 'Bob' } });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(nativePeer.localDescription.type, 'offer');
  assert.ok(fixture.socket.sent.some((frame) => frame.type === 'signal' && frame.description.type === 'offer'));
  assert.notEqual(fixture.events.at(-1).state, 'ended');
});

test('reuses one generated certificate for peer setup and subsequent signaling', async () => {
  let certificateCalls = 0;
  let boundCertificate;
  let configuredPeer;
  const fixture = await establishCreator({
    certificateFactory: async () => {
      certificateCalls += 1;
      return CERT;
    },
    peerFactory: (config) => {
      boundCertificate = config.certificates[0];
      configuredPeer ||= new FakePeer();
      return configuredPeer;
    },
  });
  assert.equal(certificateCalls, 1);
  assert.strictEqual(boundCertificate, CERT);
  assert.strictEqual(configuredPeer.localDescription.type, 'offer');
  assert.notEqual(fixture.events.at(-1).state, 'ended');
});

test('serializes a signal received while delayed peer setup is in flight', async () => {
  let resolveCertificate;
  const certificate = new Promise((resolve) => { resolveCertificate = resolve; });
  const fixture = makeSession({ certificateFactory: () => certificate });
  fixture.session.create('Alice');
  fixture.socket.open();
  fixture.socket.message({ v: 1, type: 'room', roomId: 'ABCD', selfId: 'one', role: 'creator' });
  fixture.socket.message({ v: 1, type: 'peer', peer: { id: 'two', name: 'Bob' } });
  fixture.socket.message({ v: 1, type: 'signal', description: { type: 'answer', sdp: SDP } });
  await new Promise((resolve) => setImmediate(resolve));
  resolveCertificate(CERT);
  await new Promise((resolve) => setImmediate(resolve));
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(fixture.peer.remoteDescription.sdp, SDP);
  assert.notEqual(fixture.events.at(-1).state, 'ended');
});

test('mutual confirmation and open channel gate verified state, sending, and rendering', async () => {
  const { session, events, socket, peer } = await establishCreator();
  assert.equal(events.at(-1).state, 'unverified');
  assert.throws(() => session.send('blocked'));
  peer.channel.open();
  session.confirmPeer(true);
  assert.equal(events.at(-1).state, 'unverified');
  peer.channel.message({ v: 1, type: 'verified' });
  assert.equal(events.at(-1).state, 'verified');
  session.send('hello');
  assert.deepEqual(peer.channel.sent.at(-1), { v: 1, type: 'chat', seq: 1, text: 'hello' });
  peer.channel.message({ v: 1, type: 'chat', seq: 1, text: 'world' });
  assert.deepEqual(events.at(-1).message, { direction: 'in', seq: 1, text: 'world' });
  assert.ok(socket.sent.some((frame) => frame.type === 'signal' && frame.description.type === 'offer'));
});

test('fingerprint mismatch ends the session and tears down transports', async () => {
  const { session, events, socket, peer } = await establishCreator();
  session.confirmPeer(false);
  assert.equal(events.at(-1).state, 'ended');
  assert.equal(events.at(-1).reason, 'fingerprint-mismatch');
  assert.equal(peer.closed, true);
  assert.equal(socket.readyState, 3);
  assert.throws(() => session.send('after end'));
});

test('stale callbacks from a prior generation cannot mutate a fresh session', async () => {
  const fixture = await establishCreator();
  fixture.session.end();
  const previousPeerHandler = fixture.peer.channel.onmessage;
  fixture.session.create('Alice again');
  fixture.socket.open();
  previousPeerHandler?.({ data: encodeDataFrame({ v: 1, type: 'verified' }) });
  assert.notEqual(fixture.events.at(-1).state, 'verified');
});

test('invalid sequence and unverified chat fail closed', async () => {
  const { session, events, peer } = await establishCreator();
  peer.channel.open();
  session.confirmPeer(true);
  peer.channel.message({ v: 1, type: 'verified' });
  peer.channel.message({ v: 1, type: 'chat', seq: 2, text: 'replay' });
  assert.equal(events.at(-1).state, 'ended');
  assert.equal(events.at(-1).reason, 'invalid-data');
});

test('UTF-8 chat cap, buffered amount cap, frame-rate cap, lifetime, and cleanup are enforced', async () => {
  const fixture = await establishCreator();
  const { session, events, peer, clock } = fixture;
  peer.channel.open();
  session.confirmPeer(true);
  peer.channel.message({ v: 1, type: 'verified' });
  assert.throws(() => session.send('🙂'.repeat(1025)));
  peer.channel.bufferedAmount = 262145;
  assert.throws(() => session.send('buffered'));
  peer.channel.bufferedAmount = 0;
  for (let index = 0; index < 8; index += 1) session.send(`m${index}`);
  assert.throws(() => session.send('m8'), /rate-limit/);
  assert.equal(events.at(-1).state, 'ended');
  const endedCount = events.filter((event) => event.state === 'ended').length;
  clock.advance(60 * 60 * 1000);
  assert.equal(events.filter((event) => event.state === 'ended').length, endedCount);
});

test('verified inactivity and absolute lifetime timers end sessions without reconnecting', async () => {
  const idleFixture = await establishCreator();
  idleFixture.peer.channel.open();
  idleFixture.session.confirmPeer(true);
  idleFixture.peer.channel.message({ v: 1, type: 'verified' });
  idleFixture.clock.advance(15 * 60 * 1000);
  assert.equal(idleFixture.events.at(-1).reason, 'chat-idle');

  const lifetimeFixture = makeSession();
  lifetimeFixture.session.create('Alice');
  lifetimeFixture.socket.open();
  lifetimeFixture.clock.advance(60 * 60 * 1000);
  assert.equal(lifetimeFixture.events.at(-1).reason, 'session-expired');
});
