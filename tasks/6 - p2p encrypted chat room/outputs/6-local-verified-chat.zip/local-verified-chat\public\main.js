import { createSession } from './session.js';
import { createTranscriptTracker } from './transcript.js';

const $ = (id) => document.getElementById(id);
const setupPanel = $('setup-panel');
const roomPanel = $('room-panel');
const connectionChip = $('connection-chip');
const connectionLabel = $('connection-label');
const setupError = $('setup-error');
const roomError = $('room-error');
const roomCodeDisplay = $('room-code-display');
const copyRoomCode = $('copy-room-code');
const peerName = $('peer-name');
const peerId = $('peer-id');
const yourFingerprint = $('your-fingerprint');
const peerFingerprint = $('peer-fingerprint');
const verificationBadge = $('verification-badge');
const verificationCopy = $('verification-copy');
const confirmMatch = $('confirm-match');
const confirmMismatch = $('confirm-mismatch');
const chatGate = $('chat-gate');
const transcript = $('transcript');
const transcriptEmpty = $('transcript-empty');
const composerForm = $('composer-form');
const composerInput = $('composer-input');
const sendButton = $('send-button');
const leaveButton = $('leave-button');
const createForm = $('create-form');
const joinForm = $('join-form');
const transcriptTracker = createTranscriptTracker({ transcript, empty: transcriptEmpty });

let activeSession = null;
let currentState = 'idle';
let currentRoomCode = '';

const statusLabels = {
  idle: 'Not connected',
  connecting: 'Connecting',
  waiting: 'Waiting for peer',
  unverified: 'Connected · unverified',
  verified: 'Verified channel',
  error: 'Connection error',
  ended: 'Session ended',
};

const errorLabels = {
  'invalid-name': 'Use a temporary name between 1 and 32 characters.',
  'invalid-room': 'Enter the room code exactly as provided by the creator.',
  'server-error': 'The server rejected this room operation. Try a new room or check the code.',
  'room-full': 'This room already has two participants.',
  'room-missing': 'That room is unavailable, expired, or already ended.',
  'fingerprint-mismatch': 'The fingerprints did not match. This session has been ended.',
  'certificate-mismatch': 'The local certificate did not match the active SDP. This session has been ended.',
  'certificate-unavailable': 'This browser could not create the required fresh P-256 certificate.',
  'invalid-data': 'Unexpected channel data was rejected and the session was ended.',
  'rate-limit': 'The channel exceeded its safety rate limit and was ended.',
  'chat-idle': 'The verified channel expired after a period without accepted chat.',
  'session-expired': 'The temporary session reached its lifetime limit.',
  'disconnected': 'The other participant or signaling connection disconnected.',
  'peer-left': 'The other participant left the room.',
  'ended': 'The temporary room has ended.',
};

function setHidden(element, hidden) {
  element.hidden = hidden;
}

function showError(element, code) {
  if (!code) {
    element.textContent = '';
    element.hidden = true;
    return;
  }
  element.textContent = errorLabels[code] || 'The session could not continue. Start a fresh room.';
  element.hidden = false;
}

function clearTranscript() {
  transcriptTracker.clear();
}

function addMessage(message) {
  if (!message || typeof message.text !== 'string') return;
  transcriptEmpty.hidden = true;
  const item = document.createElement('li');
  item.className = `message message-${message.direction === 'out' ? 'out' : 'in'}`;
  const meta = document.createElement('span');
  meta.className = 'message-meta';
  meta.textContent = message.direction === 'out' ? 'You' : (peerName.textContent || 'Peer');
  const body = document.createElement('p');
  body.className = 'message-body';
  body.textContent = message.text;
  item.append(meta, body);
  transcriptTracker.add(item, message.text);
  transcript.scrollTop = transcript.scrollHeight;
}

function resetRoomView() {
  currentRoomCode = '';
  roomCodeDisplay.textContent = 'Waiting for server…';
  copyRoomCode.disabled = true;
  peerName.textContent = 'Waiting for a second participant';
  peerId.textContent = 'No peer admitted';
  yourFingerprint.textContent = 'Pending local certificate…';
  peerFingerprint.textContent = 'Waiting for peer description…';
  verificationBadge.textContent = 'Unverified';
  verificationBadge.className = 'badge badge-pending';
  verificationCopy.textContent = 'Wait for both full fingerprints, then compare your value with your peer’s value through a trusted separate channel.';
  chatGate.textContent = 'Locked until both confirm';
  composerInput.value = '';
  clearTranscript();
  showError(roomError, null);
  confirmMatch.disabled = true;
  confirmMismatch.disabled = true;
  composerInput.disabled = true;
  sendButton.disabled = true;
}

function renderEvent(event) {
  if (!event || typeof event !== 'object') return;
  currentState = event.state || currentState;
  const label = statusLabels[currentState] || 'Session state';
  connectionChip.dataset.state = currentState;
  connectionLabel.textContent = label;

  if (event.room?.roomId) {
    currentRoomCode = event.room.roomId;
    roomCodeDisplay.textContent = event.room.roomId;
    copyRoomCode.disabled = false;
  }
  if (event.peer) {
    peerName.textContent = event.peer.name || 'Peer admitted';
    peerId.textContent = `Participant ${event.peer.id || 'connected'}`;
  }
  if (event.fingerprints) {
    if (event.fingerprints.your) yourFingerprint.textContent = event.fingerprints.your;
    if (event.fingerprints.peer) peerFingerprint.textContent = event.fingerprints.peer;
    if (event.fingerprints.your === null) yourFingerprint.textContent = 'Cleared with session';
    if (event.fingerprints.peer === null) peerFingerprint.textContent = 'Cleared with session';
  }

  const haveFingerprints = Boolean(event.fingerprints?.your && event.fingerprints?.peer);
  const unverified = currentState === 'unverified';
  const verified = currentState === 'verified';
  confirmMatch.disabled = !haveFingerprints || !unverified;
  confirmMismatch.disabled = !haveFingerprints || !unverified;
  composerInput.disabled = !verified;
  sendButton.disabled = !verified;
  chatGate.textContent = verified ? 'Open · ordered and reliable' : 'Locked until both confirm';

  if (verified) {
    verificationBadge.textContent = 'Verified';
    verificationBadge.className = 'badge badge-verified';
    verificationCopy.textContent = 'Both participants confirmed the full fingerprints. The channel is open; this is still not automatic human identity proof.';
  } else if (currentState === 'error' || currentState === 'ended') {
    verificationBadge.textContent = 'Ended';
    verificationBadge.className = 'badge badge-error';
  } else {
    verificationBadge.textContent = 'Unverified';
    verificationBadge.className = 'badge badge-pending';
  }

  if (event.message) addMessage(event.message);
  if (event.error?.code) showError(currentState === 'ended' ? setupError : roomError, event.error.code);

  if (currentState === 'connecting' || currentState === 'waiting' || currentState === 'unverified' || currentState === 'verified') {
    setHidden(setupPanel, true);
    setHidden(roomPanel, false);
    setHidden(setupError, true);
  }
  if (currentState === 'error' && !event.room) {
    setHidden(roomPanel, true);
    setHidden(setupPanel, false);
    showError(setupError, event.error?.code || 'server-error');
  }
  if (currentState === 'ended') {
    setHidden(roomPanel, true);
    setHidden(setupPanel, false);
    const endedCode = event.error?.code || event.reason || 'ended';
    resetRoomView();
    showError(setupError, endedCode);
  }
}

function beginSession(mode, name, roomCode) {
  showError(setupError, null);
  showError(roomError, null);
  if (activeSession) {
    try { activeSession.end('replaced'); } catch { /* no-op */ }
    activeSession = null;
  }
  resetRoomView();
  setHidden(setupPanel, true);
  setHidden(roomPanel, false);
  activeSession = createSession(renderEvent);
  if (mode === 'create') activeSession.create(name);
  else activeSession.join(name, roomCode);
}

createForm.addEventListener('submit', (event) => {
  event.preventDefault();
  beginSession('create', $('create-name').value);
});

joinForm.addEventListener('submit', (event) => {
  event.preventDefault();
  beginSession('join', $('join-name').value, $('room-code').value);
});

confirmMatch.addEventListener('click', () => {
  try { activeSession?.confirmPeer(true); } catch { showError(roomError, 'invalid-data'); }
});

confirmMismatch.addEventListener('click', () => {
  try { activeSession?.confirmPeer(false); } catch { showError(roomError, 'invalid-data'); }
});

composerForm.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!activeSession) return;
  try {
    activeSession.send(composerInput.value);
    composerInput.value = '';
    composerInput.focus();
  } catch (error) {
    const code = error?.message === 'invalid-message' ? 'invalid-data' : (error?.message || 'invalid-data');
    showError(roomError, code);
  }
});

leaveButton.addEventListener('click', () => {
  try { activeSession?.end('left'); } catch { /* no-op */ }
  clearTranscript();
});

copyRoomCode.addEventListener('click', async () => {
  if (!currentRoomCode || !navigator.clipboard?.writeText) return;
  try {
    await navigator.clipboard.writeText(currentRoomCode);
    copyRoomCode.textContent = 'Copied';
    setTimeout(() => { copyRoomCode.textContent = 'Copy code'; }, 1200);
  } catch {
    copyRoomCode.textContent = 'Select code above';
  }
});

resetRoomView();
