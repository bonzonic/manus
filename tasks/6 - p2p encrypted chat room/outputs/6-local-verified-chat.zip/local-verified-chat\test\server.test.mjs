import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { WebSocket } from 'ws';
import { createChatServer } from '../server.mjs';

const servers = [];
const fixtures = [];
const messageQueues = new WeakMap();
const VALID_FINGERPRINT = 'AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99';
const VALID_SDP = `v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0\r\nm=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\nc=IN IP4 0.0.0.0\r\na=mid:0\r\na=fingerprint:sha-256 ${VALID_FINGERPRINT}\r\na=setup:actpass\r\n`;

afterEach(async () => {
  await Promise.all(servers.splice(0).map((entry) => entry.close()));
  await Promise.all(fixtures.splice(0).map((dir) => fs.rm(dir, { recursive: true, force: true })));
});

async function running(options = {}) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'chat-server-'));
  await fs.writeFile(path.join(dir, 'index.html'), '<!doctype html><h1>fixture</h1>');
  fixtures.push(dir);
  const entry = createChatServer({ port: 0, publicDir: dir, ...options });
  const { port } = await entry.listen();
  servers.push(entry);
  return { entry, port, origin: `http://127.0.0.1:${port}`, url: `ws://127.0.0.1:${port}` };
}

function connect(url, origin, options = {}) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(url, { ...options, origin });
    ensureMessageQueue(socket);
    const timer = setTimeout(() => reject(new Error('open timeout')), 1500);
    socket.once('open', () => { clearTimeout(timer); resolve(socket); });
    socket.once('error', (error) => { clearTimeout(timer); reject(error); });
  });
}

function closed(url, origin, options = {}) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(url, { ...options, origin });
    const timer = setTimeout(() => reject(new Error('close timeout')), 1500);
    socket.once('close', (code) => { clearTimeout(timer); resolve({ socket, code }); });
    socket.once('error', () => {});
  });
}

function ensureMessageQueue(socket) {
  let queue = messageQueues.get(socket);
  if (!queue) {
    queue = { frames: [], waiters: [] };
    messageQueues.set(socket, queue);
    socket.on('message', (data, isBinary) => {
      let result;
      try { result = { frame: JSON.parse(data.toString()), isBinary }; }
      catch (error) { result = { error }; }
      const waiter = queue.waiters.shift();
      if (waiter) {
        clearTimeout(waiter.timer);
        if (result.error) waiter.reject(result.error); else waiter.resolve(result);
      } else {
        queue.frames.push(result);
      }
    });
  }
  return queue;
}

function message(socket, timeout = 1500) {
  const queue = ensureMessageQueue(socket);
  if (queue.frames.length) {
    const result = queue.frames.shift();
    return result.error ? Promise.reject(result.error) : Promise.resolve(result);
  }
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      const index = queue.waiters.indexOf(waiter);
      if (index >= 0) queue.waiters.splice(index, 1);
      reject(new Error('message timeout'));
    }, timeout);
    const waiter = { resolve, reject, timer };
    queue.waiters.push(waiter);
  });
}

async function roomPair(server) {
  const creator = await connect(server.url, server.origin);
  creator.send(JSON.stringify({ v: 1, type: 'create', name: ' Alice ' }));
  const created = (await message(creator)).frame;
  assert.equal(created.type, 'room');
  assert.equal(created.role, 'creator');
  assert.match(created.roomId, /^[A-F0-9]{12}$/);
  const joiner = await connect(server.url, server.origin);
  joiner.send(JSON.stringify({ v: 1, type: 'join', name: 'Bob', roomId: created.roomId }));
  const peerCreator = (await message(creator)).frame;
  const joined = (await message(joiner)).frame;
  const peerJoiner = (await message(joiner)).frame;
  assert.equal(peerCreator.type, 'peer');
  assert.equal(joined.type, 'room');
  assert.equal(peerJoiner.type, 'peer');
  assert.equal(peerCreator.peer.name, 'Bob');
  assert.equal(peerJoiner.peer.name, 'Alice');
  return { creator, joiner, roomId: created.roomId, peerCreator, peerJoiner };
}


test('serves static content with no-store and security headers', async () => {
  const server = await running();
  const response = await fetch(`${server.origin}/`);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('cache-control'), /no-store/);
  assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
  assert.match(response.headers.get('content-security-policy'), /default-src 'self'/);
  assert.match(await response.text(), /fixture/);
  const traversal = await fetch(`${server.origin}/%2e%2e%2fsecret`);
  assert.equal(traversal.status, 400);
});

test('assigns creator/joiner roles in order and rejects a third peer', async () => {
  const server = await running();
  const { creator, joiner, roomId } = await roomPair(server);
  const third = await connect(server.url, server.origin);
  third.send(JSON.stringify({ v: 1, type: 'join', name: 'Third', roomId }));
  assert.deepEqual((await message(third)).frame, { v: 1, type: 'error', code: 'room_full' });
  creator.close(); joiner.close(); third.close();
});

test('rejects unknown rooms and invalid names without echoing input', async () => {
  const server = await running();
  const socket = await connect(server.url, server.origin);
  socket.send(JSON.stringify({ v: 1, type: 'join', name: ' x '.repeat(20), roomId: 'ABCDEFABCDEF' }));
  assert.deepEqual((await message(socket)).frame, { v: 1, type: 'error', code: 'invalid_request' });
  socket.send(JSON.stringify({ v: 1, type: 'join', name: 'Bob', roomId: 'ABCDEFABCDEF' }));
  assert.deepEqual((await message(socket)).frame, { v: 1, type: 'error', code: 'room_not_found' });
  socket.close();
});

test('forwards only offer then answer, preserving the description shape', async () => {
  const server = await running();
  const { creator, joiner } = await roomPair(server);
  const offer = { type: 'offer', sdp: VALID_SDP };
  creator.send(JSON.stringify({ v: 1, type: 'signal', description: offer }));
  assert.deepEqual((await message(joiner)).frame, { v: 1, type: 'signal', description: offer });
  const answer = { type: 'answer', sdp: offer.sdp };
  joiner.send(JSON.stringify({ v: 1, type: 'signal', description: answer }));
  assert.deepEqual((await message(creator)).frame, { v: 1, type: 'signal', description: answer });
  creator.send(JSON.stringify({ v: 1, type: 'signal', description: answer }));
  assert.deepEqual((await message(creator)).frame, { v: 1, type: 'error', code: 'invalid_state' });
  creator.close(); joiner.close();
});

test('rejects chat/application frames and keeps privacy counters payload-free', async () => {
  const server = await running();
  const { creator } = await roomPair(server);
  creator.send(JSON.stringify({ v: 1, type: 'chat', seq: 1, text: 'secret payload' }));
  assert.deepEqual((await message(creator)).frame, { v: 1, type: 'error', code: 'unsupported_frame' });
  const privacy = await (await fetch(`${server.origin}/api/privacy`)).json();
  assert.equal(privacy.applicationMessagesForwarded, 0);
  assert.equal(privacy.payloadsStored, false);
  assert.ok(privacy.rejectedFrames >= 1);
  const serialized = JSON.stringify(privacy);
  assert.doesNotMatch(serialized, /secret|Alice|Bob|fingerprint|sdp/i);
  creator.close();
});

test('rejects missing and foreign WebSocket origins', async () => {
  const server = await running();
  await assert.rejects(connect(server.url, '', {}));
  const foreign = await closed(server.url, `http://evil.example:${server.port}`);
  assert.ok([1006, 1002].includes(foreign.code));
});

test('rejects malformed, binary, unknown, and oversized frames', async () => {
  const server = await running();
  const socket = await connect(server.url, server.origin);
  socket.send('{not-json');
  assert.deepEqual((await message(socket)).frame, { v: 1, type: 'error', code: 'malformed_frame' });
  socket.send(JSON.stringify({ v: 1, type: 'wat', payload: 'ignored' }));
  assert.deepEqual((await message(socket)).frame, { v: 1, type: 'error', code: 'unsupported_frame' });
  socket.send(Buffer.from('{"v":1,"type":"create","name":"x"}'));
  assert.deepEqual((await message(socket)).frame, { v: 1, type: 'error', code: 'malformed_frame' });
  const oversized = 'x'.repeat(140 * 1024);
  const oversizedResult = await new Promise((resolve, reject) => {
    const huge = new WebSocket(server.url, { origin: server.origin });
    huge.once('open', () => huge.send(oversized));
    huge.once('close', (code) => code === 1009 ? resolve() : reject(new Error(`close ${code}`)));
    huge.once('error', () => {});
  });
  assert.equal(oversizedResult, undefined);
  socket.close();
});

test('expires waiting rooms and ends both participants on leave', async () => {
  const server = await running({ roomTtlMs: 45 });
  const creator = await connect(server.url, server.origin);
  creator.send(JSON.stringify({ v: 1, type: 'create', name: 'Waiter' }));
  await message(creator);
  assert.deepEqual((await message(creator, 500)).frame, { v: 1, type: 'ended', reason: 'expired' });
  creator.close();

  const pair = await roomPair(server);
  pair.creator.send(JSON.stringify({ v: 1, type: 'leave' }));
  assert.deepEqual((await message(pair.joiner)).frame, { v: 1, type: 'ended', reason: 'left' });
  assert.deepEqual((await message(pair.creator)).frame, { v: 1, type: 'ended', reason: 'left' });
  const privacy = await (await fetch(`${server.origin}/api/privacy`)).json();
  assert.equal(privacy.activeRooms, 0);
  assert.equal(privacy.activeConnections, 0);
  pair.creator.close(); pair.joiner.close();
});


test('diagnostics expose only aggregate counters and HTTP rejects unsupported methods', async () => {
  const server = await running();
  const privacy = await (await fetch(`${server.origin}/api/privacy`)).json();
  assert.deepEqual(Object.keys(privacy).sort(), [
    'activeConnections', 'activeRooms', 'applicationMessagesForwarded',
    'payloadsStored', 'rejectedFrames', 'signalsForwarded',
  ].sort());
  const response = await fetch(`${server.origin}/`, { method: 'POST' });
  assert.equal(response.status, 405);
});
