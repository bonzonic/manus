const MAX_FRAME_BYTES = 32_768;
const MAX_CHAT_BYTES = 4_096;
const SHA256_FINGERPRINT = /^(?:[0-9a-f]{2}:){31}[0-9a-f]{2}$/i;
const textEncoder = typeof TextEncoder === 'function' ? new TextEncoder() : null;

export { MAX_FRAME_BYTES, MAX_CHAT_BYTES };

export function utf8Bytes(text) {
  if (typeof text !== 'string') throw new TypeError('text must be a string');
  if (textEncoder) return textEncoder.encode(text).byteLength;
  return unescape(encodeURIComponent(text)).length;
}

function canonicalFingerprint(value) {
  if (typeof value !== 'string') throw new TypeError('invalid fingerprint');
  const trimmed = value.trim();
  if (!SHA256_FINGERPRINT.test(trimmed)) throw new TypeError('invalid fingerprint');
  return trimmed.toUpperCase();
}

function sdpLines(sdp) {
  if (typeof sdp !== 'string' || sdp.length === 0 || utf8Bytes(sdp) > MAX_FRAME_BYTES) {
    throw new TypeError('invalid SDP');
  }
  return sdp.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n').filter(Boolean);
}

export function fingerprintFromSdp(sdp) {
  const lines = sdpLines(sdp);
  const values = [];
  for (const line of lines) {
    const match = /^a=fingerprint:\s*([^\s]+)\s+(.+)$/i.exec(line);
    if (!match) continue;
    if (match[1].toLowerCase() !== 'sha-256') throw new TypeError('unsupported fingerprint');
    values.push(canonicalFingerprint(match[2]));
  }
  const unique = [...new Set(values)];
  if (unique.length !== 1) throw new TypeError('missing or ambiguous fingerprint');
  return unique[0];
}

function validateDataOnlySdp(sdp) {
  const lines = sdpLines(sdp);
  const media = lines.filter((line) => line.toLowerCase().startsWith('m='));
  if (media.length !== 1 || !/^m=application\s/i.test(media[0])) return false;
  const bundleGroups = lines.filter((line) => /^a=group:BUNDLE(?:\s|$)/i.test(line));
  if (bundleGroups.length !== 1) return false;
  const bundleMids = bundleGroups[0].trim().split(/\s+/).slice(1);
  if (bundleMids.length !== 1) return false;
  const mids = lines.filter((line) => /^a=mid:/i.test(line)).map((line) => line.slice(line.indexOf(':') + 1).trim());
  if (mids.length !== 1 || mids[0] !== bundleMids[0]) return false;
  fingerprintFromSdp(sdp);
  return true;
}

export function validateDescription(description) {
  if (!description || typeof description !== 'object' || Array.isArray(description)) return false;
  const keys = Object.keys(description).sort();
  if (keys.length !== 2 || keys[0] !== 'sdp' || keys[1] !== 'type') return false;
  if (description.type !== 'offer' && description.type !== 'answer') return false;
  try {
    return validateDataOnlySdp(description.sdp);
  } catch {
    return false;
  }
}

function assertFrame(frame) {
  if (!frame || typeof frame !== 'object' || Array.isArray(frame) || frame.v !== 1 || typeof frame.type !== 'string') {
    throw new TypeError('invalid data frame');
  }
  if (frame.type === 'verified' || frame.type === 'leave') {
    if (Object.keys(frame).length !== 2) throw new TypeError('invalid control frame');
    return frame;
  }
  if (frame.type !== 'chat') throw new TypeError('unknown data frame');
  if (Object.keys(frame).length !== 4 || !Number.isSafeInteger(frame.seq) || frame.seq < 1 || typeof frame.text !== 'string') {
    throw new TypeError('invalid chat frame');
  }
  if (utf8Bytes(frame.text) > MAX_CHAT_BYTES) throw new RangeError('chat frame too large');
  return frame;
}

export function encodeDataFrame(frame) {
  assertFrame(frame);
  const encoded = JSON.stringify(frame);
  if (utf8Bytes(encoded) > MAX_FRAME_BYTES) throw new RangeError('data frame too large');
  return encoded;
}

export function parseDataFrame(raw) {
  if (typeof raw !== 'string' || utf8Bytes(raw) > MAX_FRAME_BYTES) throw new TypeError('invalid data frame payload');
  let frame;
  try {
    frame = JSON.parse(raw);
  } catch {
    throw new TypeError('malformed data frame');
  }
  assertFrame(frame);
  return frame;
}
