import { utf8Bytes } from './protocol.js';

const MAX_TRANSCRIPT_MESSAGES = 200;
const MAX_TRANSCRIPT_BYTES = 512 * 1024;

export function createTranscriptTracker({ transcript, empty }) {
  const entries = [];
  let byteCount = 0;

  function clear() {
    for (const entry of entries) entry.node.remove();
    entries.length = 0;
    byteCount = 0;
    for (const child of [...transcript.children]) {
      if (child !== empty) child.remove();
    }
    empty.hidden = false;
  }

  function add(node, text) {
    const bytes = utf8Bytes(text);
    transcript.append(node);
    entries.push({ node, bytes });
    byteCount += bytes;
    empty.hidden = true;
    while (entries.length > MAX_TRANSCRIPT_MESSAGES || byteCount > MAX_TRANSCRIPT_BYTES) {
      const oldest = entries.shift();
      byteCount -= oldest.bytes;
      oldest.node.remove();
    }
  }

  return { add, clear };
}
