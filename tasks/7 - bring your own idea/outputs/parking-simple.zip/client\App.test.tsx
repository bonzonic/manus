// @vitest-environment jsdom
import { afterEach, it, expect } from 'vitest';
import { cleanup, render, screen, fireEvent } from '@testing-library/react';
import { App } from './App';
afterEach(cleanup);
it('shows two ready-made layouts, automatically routes from Ground, and hides advanced controls',()=>{
  render(<App/>);
  expect(screen.getByRole('button',{name:'Layout 1'})).toBeTruthy();
  expect(screen.getByRole('button',{name:'Layout 2'})).toBeTruthy();
  expect(screen.queryByLabelText('Start from')).toBeNull();
  expect(screen.queryByText('Build layout')).toBeNull();
  expect(screen.queryByText('Management integration')).toBeNull();
  expect(screen.getByRole('status').textContent).toContain('A-03');
  fireEvent.click(screen.getByRole('button',{name:'Layout 2'}));
  expect(screen.getByRole('status').textContent).toContain('B-03');
  expect(screen.getByText('Ground entrance')).toBeTruthy();
});
