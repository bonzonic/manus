import { useMemo, useState } from 'react';
import { makeSimpleLayouts } from '../shared/fixtures/simple-layouts';
import { routing } from '../shared/routing';
import './simple.css';

export function App(){
  const layouts=useMemo(makeSimpleLayouts,[]);
  const [index,setIndex]=useState(0);
  const map=layouts[index];
  const outcome=useMemo(()=>routing.findFastestAvailable(map,{startNodeId:'entrance'}),[map]);
  const route=outcome.ok?outcome.route:undefined;
  const byId=new Map(map.nodes.map(node=>[node.id,node]));
  const points=route?.nodeIds.map(id=>{const n=byId.get(id)!;return `${n.x},${n.y}`;}).join(' ');
  const spaces=map.nodes.filter(node=>node.kind==='space');
  return <main className="simple-parking">
    <header className="simple-header"><div className="simple-brand"><img src="/favicon.svg" alt="" width="36" height="36"/><h1>Find parking</h1></div><span>Ground entrance</span></header>
    <nav className="simple-tabs" aria-label="Parking layouts">{layouts.map((layout,i)=><button key={layout.id} aria-pressed={i===index} onClick={()=>setIndex(i)}>Layout {i+1}</button>)}</nav>
    <section className="simple-recommendation" role="status"><div><span className="simple-eyebrow">Your closest available space</span><strong>{route?route.destinationSpaceId:'No space available'}</strong></div>{route&&<p>{Math.round(route.totalDurationSeconds)} sec <span>·</span> {Math.round(route.totalDistanceMeters)} m</p>}</section>
    <section className="simple-board" aria-label={map.name}>
      <svg viewBox="0 0 100 65" role="img" aria-label={`${map.name}: route from Ground entrance to ${route?.destinationSpaceId}`}>
        <defs><pattern id="simple-grid" width="5" height="5" patternUnits="userSpaceOnUse"><path d="M5 0H0V5" fill="none" stroke="#e5ebee" strokeWidth=".1"/></pattern><marker id="simple-arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="2.5" markerHeight="2.5" markerUnits="userSpaceOnUse" orient="auto"><path d="M0 0L10 5L0 10" fill="#81929d"/></marker></defs>
        <rect width="100" height="65" fill="url(#simple-grid)"/><rect x="3" y="3" width="94" height="59" rx="2" fill="none" stroke="#d3dde2" strokeWidth=".25"/>
        <text x="7" y="8" fontSize="2" fill="#637883">{map.name}</text>
        {map.edges.map(edge=>{const a=byId.get(edge.fromNodeId)!,b=byId.get(edge.toNodeId)!;return <g key={edge.id}><line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={edge.kind==='road'?'#d6e0e6':'#b3c2cb'} strokeWidth={edge.kind==='road'?5:.4} strokeLinecap="round"/>{edge.kind==='road'&&<line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#a7b8c2" strokeWidth=".15" strokeDasharray="1 1" markerEnd={edge.direction==='forward'?'url(#simple-arrow)':undefined}/>}</g>;})}
        {points&&<polyline points={points} stroke="#176b87" strokeWidth=".8" strokeLinecap="round" strokeLinejoin="round" fill="none"/>}
        {spaces.map(node=><g key={node.id}><g transform={`translate(${node.x} ${node.y}) rotate(${node.headingDegrees})`}><rect x="-2" y="-3" width="4" height="6" rx=".4" fill={node.status==='free'?'#bce3ce':'#eff2f4'} stroke={node.id===route?.destinationSpaceId?'#176b87':node.status==='free'?'#58876b':'#a6b5be'} strokeWidth={node.id===route?.destinationSpaceId?.toString()?'.65':'.25'}/>{node.status==='occupied'&&<rect x="-1.1" y="-2" width="2.2" height="4" rx=".6" fill="#c1cbd1"/>}</g><text x={node.x} y={node.y+5.1} textAnchor="middle" fontSize="1.6" fill="#355361">{node.id}</text></g>)}
        <circle cx={byId.get('entrance')!.x} cy={byId.get('entrance')!.y} r="1.3" fill="#176b87" stroke="white" strokeWidth=".4"/><text x={byId.get('entrance')!.x} y={byId.get('entrance')!.y+5} textAnchor="middle" fontSize="1.6" fill="#176b87">Entry</text>
      </svg>
    </section>
    <footer className="simple-legend"><span><i className="legend-free"/>Available</span><span><i className="legend-taken"/>Taken</span><span><i className="legend-route"/>Your route</span><small>Demo data</small></footer>
  </main>;
}
