# Parking Navigator

A plain-local React/Vite + Node/Express app for authoring a 2D parking network and finding the fastest route to an available space. Uses synthetic data, Dijkstra travel-time routing, CSV interchange and a real REST/WebSocket backend.

## Run locally

Requires Node 22.12 or compatible Node 22 and npm. In PowerShell, from this directory:

```powershell
npm ci
npm run dev
```

Open http://127.0.0.1:5173. The backend listens at http://127.0.0.1:3001. No cloud account or managed Manus service is required.

For a built version:

```powershell
npm run build
npm start
```

The built server serves the frontend and API together at http://127.0.0.1:3000. `PORT` and `HOST` environment variables can override its listener. `ALLOWED_ORIGINS` is a comma-separated list for non-local deployment; no public deployment is included.

## Management key

On local startup, if `MANAGEMENT_TOKEN` is not supplied, the server creates a random key in `.data/management.key`. It does not print the key or ship it in frontend code. Expand **Management integration** at the bottom of the app and use **Load local key file** to choose that file, or paste its contents into the password field. The key is held in memory only and is lost when the browser reloads. The key and saved map are ignored local data; never commit them.

Set `MANAGEMENT_TOKEN` explicitly for any future public hosting. For example, use the hosting provider's protected environment settings, not a frontend build variable.

## Try the demo

The seeded Northpoint lot has Ground and Floors 1–5. Choose Entry A and find parking. The direct express-ramp path to Floor 5 takes **60 modelled seconds**, while the Floor-1 alternative takes **90 seconds**. The disconnected free space never wins.

Load the management key, then use **Simulate a sensor update** to mark the Floor-5 target occupied. This sends a real REST write; WebSockets update connected tabs. Recalculate explicitly and the Floor-1 alternative wins. A target is not reserved just because a route points to it.

Switch to **Build layout**. Add floors, roads, spaces and ramps through placement tools and inspector forms. Connect road endpoints explicitly. A space needs a parking-access edge to a same-floor road junction. A ramp may connect Ground directly to Floor 5; skipped floors do not gain exits. Save requires the key. CSV import changes the draft; export downloads it, and save replaces the authoritative layout with a revision check.

## Data and integration

The model uses metres, stable IDs, explicit floor elevations, directed edges and positive length/speed weights. Backend map data is saved locally in `.data/map.json`; this survives local restarts. Browser drafts are not durable in this cut-scope version. Export CSV before leaving unsaved work.

See [integration documentation](docs/integration.md) for payloads and the schema. Free hosting such as Render can later run the Node app, but its free backend sleeps and its filesystem is ephemeral. Hosted durability needs an external store. This version has not been publicly deployed.

## Checks

```powershell
npm test
npm run typecheck
npm run build
```

On this Manus-controlled Windows device, native esbuild may require permission to read ancestor directories during configuration loading. That is a local execution-policy issue, not a request to change your system ACLs or install another toolchain.

## Deliberate deadline cuts

No 3D, GPS, waiting-car detection, OKU allocation, reservations or automatic rerouting. Undo/redo, advanced drag/pan/snapping, automatic road splitting, comprehensive keyboard editing, browser draft recovery and Docker/Render deployment packaging are deferred. Basic editing and real integration remain; this is a demonstrable prototype, not a production parking service.

The initial SVG board is a fixed **100×65 metre surface**. Wider imported graphs can still be validated and routed through the APIs, but auto-fit and large-map camera editing are follow-ups. Node starts are selected manually, not detected by GPS. CSV is intended for machine interchange, not for opening untrusted labels as spreadsheet formulas.

The packaged [verification note](docs/verification.md) records the actual checks, browser live-update demo and remaining limitations.
