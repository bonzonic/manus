import { useEffect, useMemo, useState } from 'react';
import type { ConnectionState, ParkingStatus, Snapshot } from '../shared/contracts';
import { csv } from '../shared/csv';
import { BuilderView } from './builder/BuilderView';
import { MapCanvas } from './map/MapCanvas';
import { DriverView } from './driver/DriverView';
import { createParkingApi } from './integration/api-client';
import { createLiveMapClient } from './integration/live-map-client';

export function App() {
  const api = useMemo(() => createParkingApi(), []);
  const live = useMemo(() => createLiveMapClient(), []);
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [connection, setConnection] = useState<ConnectionState>('connecting');
  const [mode, setMode] = useState<'driver'|'builder'>('driver');
  const [error, setError] = useState('');
  const [managementToken, setManagementToken] = useState('');
  const [spaceId, setSpaceId] = useState('space-f5-target');
  const [status, setStatus] = useState<ParkingStatus>('occupied');
  const [busy, setBusy] = useState(false);
  const [managementMessage, setManagementMessage] = useState('');
  const apply = (next: Snapshot) => setSnapshot(current => !current || next.epoch !== current.epoch || next.revision >= current.revision ? next : current);
  useEffect(() => {
    let disposed = false;
    let unsubscribe: (() => void) | undefined;
    api.getMap().then(initial => {
      if (disposed) return;
      setSnapshot(initial);
      unsubscribe = live.subscribe(next => { if (!disposed) apply(next); }, state => { if (!disposed) setConnection(state); });
    }).catch(() => { if (!disposed) { setError('The local backend is not reachable. Start the server, then reload this page.'); setConnection('offline'); } });
    return () => { disposed = true; unsubscribe?.(); };
  }, [api, live]);
  const spaces = snapshot?.map.nodes.filter(n => n.kind === 'space') ?? [];
  const free = spaces.filter(n => n.status === 'free').length;
  async function updateAvailability() {
    if (!snapshot || !managementToken || !spaceId) return;
    setBusy(true); setManagementMessage('');
    try {
      const next = await api.setAvailability({ expectedEpoch: snapshot.epoch, expectedRevision: snapshot.revision, spaceId, status }, managementToken);
      apply(next); setManagementMessage('Availability updated. Connected clients receive the new snapshot.');
    } catch (err) { setManagementMessage(err instanceof Error ? err.message : 'Could not update availability. Reload the map and try again.'); }
    finally { setBusy(false); }
  }
  return <div className="app-shell">
    <header className="app-header">
      <a className="app-brand" href="/" aria-label="Parking Navigator home"><img src="/favicon.svg" alt="" width="36" height="36"/><span>Parking<span className="brand-secondary">Navigator</span></span></a>
      <div className="lot-heading"><strong>{snapshot?.map.name ?? 'Connecting to your parking lot'}</strong><span>2D network · multi-floor guidance</span></div>
      <nav className="mode-switch" aria-label="Application mode"><button aria-pressed={mode === 'driver'} onClick={() => setMode('driver')}>Find parking</button><button aria-pressed={mode === 'builder'} onClick={() => setMode('builder')}>Build layout</button></nav>
      <span className={`connection-pill ${connection}`} role="status"><i/>{connection === 'live' ? 'Live backend' : connection === 'connecting' ? 'Connecting' : connection === 'reconnecting' ? 'Reconnecting' : 'Offline'}</span>
    </header>
    <div className="context-strip"><span><strong>Synthetic demo</strong> · no sensors or reservations</span>{snapshot && <span>{snapshot.map.floors.length} floors <span className="strip-divider">/</span> {spaces.length} spaces <span className="strip-divider">/</span> {free} reported free <span className="strip-divider">/</span> revision {snapshot.revision}</span>}</div>
    <main>
      {error && <div className="app-error" role="alert"><h1>Start the local backend</h1><p>{error}</p><button onClick={() => window.location.reload()}>Reload connection</button></div>}
      {!snapshot && !error && <div className="loading-panel"><div className="loading-symbol">P</div><h1>Opening your parking network</h1><p>Loading the floor graph and live availability.</p></div>}
      {snapshot && <>
        <section className="mode-section" hidden={mode !== 'driver'} aria-label="Driver view"><DriverView snapshot={snapshot} connectionState={connection} api={api} Renderer={MapCanvas}/></section>
        <section className="mode-section" hidden={mode !== 'builder'} aria-label="Builder view"><BuilderView snapshot={snapshot} csv={csv} api={api} managementToken={managementToken} Renderer={MapCanvas} onSaved={apply}/></section>
      </>}
    </main>
    {snapshot && <details className="management-tools">
      <summary>Management integration <span>{managementToken ? 'Key loaded in memory' : 'Unlock edits and simulate live availability'}</span></summary>
      <div className="management-content">
        <div className="key-panel"><label htmlFor="management-key">Management key</label><input id="management-key" type="password" value={managementToken} onChange={e => setManagementToken(e.target.value)} placeholder="Paste your local management key" autoComplete="off"/>
          <label className="key-file">Load local key file<input type="file" accept=".key,.txt" onChange={async e => { const file = e.target.files?.[0]; if (file) { const text = (await file.text()).trim(); if (text.length <= 2048) setManagementToken(text); } e.target.value = ''; }}/></label>
          <p>The server creates <code>.data/management.key</code>. Load that file or paste its value. Your key stays in memory, not browser storage.</p>
        </div>
        <div className="availability-panel"><h2>Simulate a sensor update</h2><p>This sends a real REST mutation. WebSockets push it to every connected client.</p><div className="availability-fields"><label>Space<select value={spaceId} onChange={e => setSpaceId(e.target.value)}>{spaces.map(n => <option key={n.id} value={n.id}>{n.label} · {snapshot.map.floors.find(f => f.id === n.floorId)?.label} · {n.status}</option>)}</select></label><label>Status<select value={status} onChange={e => setStatus(e.target.value as ParkingStatus)}><option value="occupied">Occupied</option><option value="free">Free</option><option value="closed">Closed</option></select></label><button disabled={!managementToken || busy || !spaces.some(n => n.id === spaceId)} onClick={updateAvailability}>{busy ? 'Updating…' : 'Send update'}</button></div>{managementMessage && <p className="management-result" role="status">{managementMessage}</p>}</div>
      </div>
    </details>}
    <footer className="app-footer"><span>Explicit roads. Real connections. Modelled travel time.</span><span>Available does not mean reserved.</span></footer>
  </div>;
}
