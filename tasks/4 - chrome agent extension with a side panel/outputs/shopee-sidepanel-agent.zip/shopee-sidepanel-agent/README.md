# Shopee/OpenRouter side-panel agent — local test build

**Status: LOCAL TEST BUILD.** This is not an all-must-haves-complete release, secure key vault, public shipment, or native/live verification. The independent code checks reported **34/34 tests** and **11/11 syntax checks** passing, but native Chrome, live OpenRouter, and live Shopee evidence are still unavailable. The package receipt records the candidate fingerprint; do not treat a ZIP as verified until the parent’s corrected receipt says so.

## Load locally

1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode**.
3. Choose **Load unpacked**.
4. Select the existing `extension` subfolder at:

   `C:/Users/wongn/Documents/Interview/Manus/tasks/4 - chrome agent extension with a side panel/outputs/shopee-sidepanel-agent/extension`

If testing a parent-rebuilt ZIP, extract it first and select its `extension` subfolder only after the parent confirms the receipt. Do not publish or share this local directory.

## First supervised test

1. Navigate manually to `https://shopee.com.my`. The user must handle login, CAPTCHA, verification codes, and other site challenges manually.
2. From the Chrome toolbar, open the extension Side Panel.
3. In **Shopee region (required)**, select **Shopee Malaysia (https://shopee.com.my)**. Other origins, redirects, and changed-origin runs are expected to stop.
4. In **OpenRouter session key (masked; never packaged)**, enter only your own low-limit development key, then press **Save session settings**. Never put a key in chat. The key is intended for trusted extension session state only; it is not returned as readable text, logged, embedded, or written to `.env`.
5. Press **Refresh live model catalog**. Review the live result, model ID/name, prompt/completion/request prices, refresh time, and structured-output/response-format or other compatibility labels. The cheapest eligible default may be preferred, but permitted choices should not be silently hidden. GPT generation `>=6` and literal Claude Fable generation `>=5` are excluded.
6. Enter a natural request in **Request**, press **Observe selected Shopee tab**, review the proposal, and press **Run plan / advance**.
7. Review and approve each proposed fill or click. For a cart action, use **Exact approval** only after checking the exact item, item ID/fingerprint, variant/options, positive quantity, region, expected result, and target fingerprint. Checkout, buy-now, payment, order submission, identity, login, OTP, and CAPTCHA actions must remain manual and unavailable.
8. After an approved cart click, rely only on fresh rendered evidence. If the expected cart change is not visible, the result must remain **unknown / action sent; outcome unverified**; do not retry automatically.

The panel also exposes **Pause**, **Resume**, **Cancel**, **Export sanitized timeline**, and **Clear session**. Use **Clear session** after testing. It removes extension-local key/session state; it cannot promise deletion or zero retention by OpenRouter or another provider.

## Data and safety boundaries

The extension is designed for one supervised tab and rendered page context. Raw snapshots, prompts, page text, existing field values, and shopping details are memory-only and must not be placed in logs or durable storage. Necessary minimal run metadata and sanitized logs/key state may use trusted extension `chrome.storage.session`; no `chrome.storage.local`, `chrome.storage.sync`, telemetry, analytics, database, remote task history, or bundled secret is intended. Page context is sent to the selected OpenRouter/provider for processing, and provider retention is not guaranteed by local clearing.

Do not add a real key to source, `.env`, browser history, telemetry, screenshots, chat, or a ZIP. This local unpacked build is readable by the machine owner/devtools and is not a private secure vault. Shopee selectors, native side-panel behavior, live model/provider calls, redirects, anti-bot/CAPTCHA handling, and real cart confirmation remain **expected but not verified** until a fresh manual/native test records evidence.
